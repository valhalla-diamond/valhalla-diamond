
import Webshop from '../components/Webshop';

export default function Home() {
  return <Webshop />;
}
